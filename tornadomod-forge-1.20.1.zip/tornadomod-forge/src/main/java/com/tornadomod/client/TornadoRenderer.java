package com.tornadomod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.tornadomod.TornadoMod;
import com.tornadomod.entity.TornadoEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Draws the tornado as real clouds: hundreds of soft, camera-facing cloud puffs.
 * <ul>
 *   <li>the funnel: rings of puffs spiralling up, dirty brown-grey at the ground, lighter higher up, swaying as it rises</li>
 *   <li>the storm cloud: a big dark mass at the top, with a drooping wall cloud under it</li>
 *   <li>inflow bands: dark cloud streaming in from far away and being sucked into the top, so the clouds visibly gather</li>
 * </ul>
 * Dust and flying debris at the base are particles (TornadoEntity#clientTick).
 */
public class TornadoRenderer extends EntityRenderer<TornadoEntity> {
	private static final ResourceLocation TEXTURE = new ResourceLocation(TornadoMod.MOD_ID, "textures/entity/cloud.png");
	private static final int FUNNEL_LAYERS = 28;
	private static final int PUFFS_PER_LAYER = 6;
	private static final double TWO_PI = Math.PI * 2.0;
	private static final double FUNNEL_SPIN = -0.04;  // radians per tick
	private static final double CLOUD_SPIN = -0.01;

	/** One soft cloud sprite. Position is relative to the tornado's base. */
	private record Puff(float x, float y, float z, float size, float roll, float r, float g, float b, float a) {
	}

	public TornadoRenderer(EntityRendererProvider.Context context) {
		super(context);
		this.shadowRadius = 0.0f;
	}

	@Override
	public void render(TornadoEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
					   MultiBufferSource buffer, int packedLight) {
		float time = entity.tickCount + partialTick;
		int light = LightTexture.pack(Math.max(LightTexture.block(packedLight), 3), Math.max(LightTexture.sky(packedLight), 9));
		double base = entity.baseRadius();
		double height = entity.funnelHeight();

		List<Puff> puffs = new ArrayList<>(320);
		addFunnel(puffs, time, base, height);
		addStormCloud(puffs, time, base, height);

		// draw far to near, so the soft edges blend into each other properly
		Vec3 cam = this.entityRenderDispatcher.camera.getPosition();
		Vec3 pos = entity.getPosition(partialTick);
		final float cx = (float) (cam.x - pos.x);
		final float cy = (float) (cam.y - pos.y);
		final float cz = (float) (cam.z - pos.z);
		puffs.sort((p, q) -> Double.compare(dist2(q, cx, cy, cz), dist2(p, cx, cy, cz)));

		VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucent(TEXTURE));
		for (Puff p : puffs) {
			if (p.a() > 0.02f) {
				drawPuff(vc, poseStack, p, light);
			}
		}

		super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
	}

	// ------------------------------------------------------------------ shape

	private static double dist2(Puff p, float cx, float cy, float cz) {
		double dx = p.x() - cx, dy = p.y() - cy, dz = p.z() - cz;
		return dx * dx + dy * dy + dz * dz;
	}

	private static float hash(int a, int b) {
		double s = Math.sin(a * 12.9898 + b * 78.233) * 43758.5453;
		return (float) (s - Math.floor(s));
	}

	/** Funnel radius at t (0 = ground, 1 = cloud base). */
	private static double radius(double t, double base) {
		return 0.30 * base + 1.70 * base * Math.pow(t, 1.6);
	}

	/** The funnel bends a little as it rises, like a real one. */
	private static double centerX(double t, double base, float time) {
		return Math.sin(time * 0.04 + t * 2.5) * base * 0.35 * Math.pow(t, 1.2);
	}

	private static double centerZ(double t, double base, float time) {
		return Math.cos(time * 0.035 + t * 2.1) * base * 0.35 * Math.pow(t, 1.2);
	}

	private static void addFunnel(List<Puff> puffs, float time, double base, double height) {
		for (int l = 0; l < FUNNEL_LAYERS; l++) {
			double t = (l + 0.5) / FUNNEL_LAYERS;
			double rad = radius(t, base);
			double ox = centerX(t, base, time);
			double oz = centerZ(t, base, time);
			float y = (float) (t * height);
			float fade = (float) Math.min(1.0, 0.45 + t * 5.0);

			// dirty brown-grey at the ground, bright grey-white in the lower middle, a bit darker at the top
			float br = (float) (0.52 + 0.20 * Math.sin(Math.min(1.0, t * 1.4) * Math.PI));
			float dirt = (float) Math.max(0.0, 1.0 - t * 5.0) * 0.12f;

			for (int k = 0; k < PUFFS_PER_LAYER; k++) {
				double a = TWO_PI * k / PUFFS_PER_LAYER + l * 0.75 + FUNNEL_SPIN * time + t * 1.3;
				double rr = rad * (0.70 + 0.30 * hash(l, k));
				float size = (float) (Math.max(3.0, rad * 1.15 + 2.5) * (0.85 + 0.30 * hash(k, l + 50)));
				puffs.add(new Puff((float) (ox + Math.cos(a) * rr), y, (float) (oz + Math.sin(a) * rr), size,
						hash(l, k + 20) * 360.0f, br + dirt, br, br - dirt, 0.55f * fade));
			}
			// darker core so the funnel isn't see-through
			for (int k = 0; k < 2; k++) {
				double a = k * Math.PI + l * 1.1 + FUNNEL_SPIN * time;
				float size = (float) Math.max(3.0, rad * 1.4 + 2.0);
				puffs.add(new Puff((float) (ox + Math.cos(a) * rad * 0.25), y, (float) (oz + Math.sin(a) * rad * 0.25), size,
						hash(l, k + 70) * 360.0f, br * 0.7f + dirt, br * 0.7f, br * 0.7f - dirt, 0.5f * fade));
			}
		}
	}

	private static void addStormCloud(List<Puff> puffs, float time, double base, double height) {
		double cx = centerX(1.0, base, time);
		double cz = centerZ(1.0, base, time);
		double puffSize = Math.max(5.0, base * 2.2);

		// the dark main mass, a thick disc that turns slowly
		for (int i = 0; i < 36; i++) {
			double a = TWO_PI * hash(i, 1) + CLOUD_SPIN * time;
			double rr = base * (0.3 + 3.6 * Math.sqrt(hash(i, 2)));
			float y = (float) (height + (hash(i, 3) - 0.5) * 5.0);
			float shade = 0.20f + 0.12f * hash(i, 5);
			puffs.add(new Puff((float) (cx + Math.cos(a) * rr), y, (float) (cz + Math.sin(a) * rr),
					(float) (puffSize * (1.0 + 0.8 * hash(i, 4))), hash(i, 6) * 360.0f,
					shade, shade, shade + 0.02f, 0.85f));
		}
		// the wall cloud that droops under the middle of it
		for (int i = 0; i < 9; i++) {
			double a = TWO_PI * hash(i, 11) + CLOUD_SPIN * 1.5 * time;
			double rr = base * (0.2 + 1.4 * hash(i, 12));
			float y = (float) (height - 3.0 - hash(i, 13) * 3.5);
			float shade = 0.15f + 0.08f * hash(i, 14);
			puffs.add(new Puff((float) (cx + Math.cos(a) * rr), y, (float) (cz + Math.sin(a) * rr),
					(float) (puffSize * (0.9 + 0.5 * hash(i, 15))), hash(i, 16) * 360.0f,
					shade, shade, shade + 0.02f, 0.85f));
		}
		// inflow bands: dark cloud drifting in from far away and being pulled into the top, over and over
		int bands = 30;
		for (int i = 0; i < bands; i++) {
			float phase = (float) ((time * 0.0025 + (double) i / bands) % 1.0);
			double a = i * 2.399963 + phase * 2.6 + CLOUD_SPIN * time;
			double rr = (9.0 - 7.0 * phase) * base;
			float y = (float) (height + 3.0 + 3.0 * Math.sin(i * 1.7) - phase * 4.0);
			float alpha = (float) (0.80 * Math.pow(Math.sin(Math.PI * phase), 0.7));
			puffs.add(new Puff((float) (cx + Math.cos(a) * rr), y, (float) (cz + Math.sin(a) * rr),
					(float) (puffSize * 1.3), hash(i, 21) * 360.0f, 0.30f, 0.30f, 0.33f, alpha));
		}
	}

	// ------------------------------------------------------------------ drawing

	private void drawPuff(VertexConsumer vc, PoseStack poseStack, Puff p, int light) {
		poseStack.pushPose();
		poseStack.translate(p.x(), p.y(), p.z());
		poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation()); // always face the camera
		poseStack.mulPose(Axis.ZP.rotationDegrees(p.roll()));
		PoseStack.Pose pose = poseStack.last();
		float s = p.size() * 0.5f;
		vertex(vc, pose, -s, -s, 0.0f, 0.0f, 1.0f, p, light);
		vertex(vc, pose, -s, s, 0.0f, 0.0f, 0.0f, p, light);
		vertex(vc, pose, s, s, 0.0f, 1.0f, 0.0f, p, light);
		vertex(vc, pose, s, -s, 0.0f, 1.0f, 1.0f, p, light);
		poseStack.popPose();
	}

	private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z,
							   float u, float v, Puff p, int light) {
		vc.vertex(pose.pose(), x, y, z)
				.color(p.r(), p.g(), p.b(), p.a())
				.uv(u, v)
				.overlayCoords(OverlayTexture.NO_OVERLAY)
				.uv2(light)
				.normal(pose.normal(), 0.0f, 0.0f, 1.0f)
				.endVertex();
	}

	@Override
	public ResourceLocation getTextureLocation(TornadoEntity entity) {
		return TEXTURE;
	}
}
