package com.tornadomod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.tornadomod.TornadoMod;
import com.tornadomod.entity.TornadoEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * Draws the tornado as a solid, textured 3D funnel: two nested spinning cones that sway as they rise,
 * topped by a dark flat storm cloud. Dust and flying debris at the base are particles (TornadoEntity#clientTick).
 */
public class TornadoRenderer extends EntityRenderer<TornadoEntity> {
	private static final ResourceLocation TEXTURE = new ResourceLocation(TornadoMod.MOD_ID, "textures/entity/tornado.png");
	private static final int SEGMENTS = 32;
	private static final int LAYERS = 26;
	private static final double TWO_PI = Math.PI * 2.0;

	public TornadoRenderer(EntityRendererProvider.Context context) {
		super(context);
		this.shadowRadius = 0.0f;
	}

	@Override
	public void render(TornadoEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
					   MultiBufferSource buffer, int packedLight) {
		float time = entity.tickCount + partialTick;
		int light = LightTexture.pack(Math.max(LightTexture.block(packedLight), 3), Math.max(LightTexture.sky(packedLight), 9));
		VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucent(TEXTURE));
		PoseStack.Pose pose = poseStack.last();

		double base = entity.baseRadius();
		double height = entity.funnelHeight();

		// inner core first, then the outer shell
		funnel(vc, pose, time, base, height, 0.80, -0.11f, 2.0f, 0.95f, 0.30f, light);
		funnel(vc, pose, time, base, height, 1.00, -0.07f, 1.0f, 0.80f, 0.36f, light);
		cloud(vc, pose, time, base, height, light);

		super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
	}

	// ------------------------------------------------------------------ shape

	private static double radius(double t, double base, double scale) {
		double rMin = 0.30 * base * scale;
		double rMax = 2.0 * base * scale;
		return rMin + (rMax - rMin) * Math.pow(t, 1.6);
	}

	/** The funnel bends a little as it rises, like a real one. */
	private static double centerX(double t, double base, float time) {
		return Math.sin(time * 0.04 + t * 2.5) * base * 0.35 * Math.pow(t, 1.2);
	}

	private static double centerZ(double t, double base, float time) {
		return Math.cos(time * 0.035 + t * 2.1) * base * 0.35 * Math.pow(t, 1.2);
	}

	private static void vertex(VertexConsumer vc, PoseStack.Pose pose, double x, double y, double z,
							   float u, float v, float shade, float alpha, int light) {
		vc.vertex(pose.pose(), (float) x, (float) y, (float) z)
				.color(shade, shade, shade, alpha)
				.uv(u, v)
				.overlayCoords(OverlayTexture.NO_OVERLAY)
				.uv2(light)
				.normal(pose.normal(), 0.0f, 1.0f, 0.0f)
				.endVertex();
	}

	private static void funnelVertex(VertexConsumer vc, PoseStack.Pose pose, double t, int seg, float time,
									 double base, double height, double scale, float spin, float uvScale,
									 float alpha, float darkest, int light) {
		double a = TWO_PI * seg / SEGMENTS + spin * time + t * 1.3;
		double rad = radius(t, base, scale);
		double x = centerX(t, base, time) + Math.cos(a) * rad;
		double z = centerZ(t, base, time) + Math.sin(a) * rad;
		float u = (float) (seg * 3.0 / SEGMENTS) * uvScale + time * 0.01f;
		float v = (float) (t * 2.0) * uvScale - time * 0.02f * uvScale;
		float shade = darkest + 0.30f * (float) t;
		float al = alpha * (float) Math.min(1.0, 0.55 + t * 4.0);
		vertex(vc, pose, x, t * height, z, u, v, shade, al, light);
	}

	private static void funnel(VertexConsumer vc, PoseStack.Pose pose, float time, double base, double height,
							   double scale, float spin, float uvScale, float alpha, float darkest, int light) {
		for (int i = 0; i < LAYERS; i++) {
			double t0 = (double) i / LAYERS;
			double t1 = (double) (i + 1) / LAYERS;
			for (int j = 0; j < SEGMENTS; j++) {
				funnelVertex(vc, pose, t0, j, time, base, height, scale, spin, uvScale, alpha, darkest, light);
				funnelVertex(vc, pose, t0, j + 1, time, base, height, scale, spin, uvScale, alpha, darkest, light);
				funnelVertex(vc, pose, t1, j + 1, time, base, height, scale, spin, uvScale, alpha, darkest, light);
				funnelVertex(vc, pose, t1, j, time, base, height, scale, spin, uvScale, alpha, darkest, light);
			}
		}
	}

	/** A few stacked dark discs at the top of the funnel: the wall cloud it hangs from. */
	private static void cloud(VertexConsumer vc, PoseStack.Pose pose, float time, double base, double height, int light) {
		double cx = centerX(1.0, base, time);
		double cz = centerZ(1.0, base, time);
		double inner = 1.5 * base;
		for (int k = 0; k < 3; k++) {
			double outer = (3.4 + 0.9 * k) * base;
			double y = height - 2.5 + k * 1.8;
			float shade = 0.16f + 0.04f * k;
			double spin = -0.02 * (k + 1) * time;
			for (int j = 0; j < SEGMENTS; j++) {
				double a0 = TWO_PI * j / SEGMENTS + spin;
				double a1 = TWO_PI * (j + 1) / SEGMENTS + spin;
				float u0 = (float) (j * 4.0 / SEGMENTS);
				float u1 = (float) ((j + 1) * 4.0 / SEGMENTS);
				vertex(vc, pose, cx + Math.cos(a0) * inner, y, cz + Math.sin(a0) * inner, u0, 0.0f, shade, 0.92f, light);
				vertex(vc, pose, cx + Math.cos(a0) * outer, y + 0.8, cz + Math.sin(a0) * outer, u0, 1.5f, shade, 0.70f, light);
				vertex(vc, pose, cx + Math.cos(a1) * outer, y + 0.8, cz + Math.sin(a1) * outer, u1, 1.5f, shade, 0.70f, light);
				vertex(vc, pose, cx + Math.cos(a1) * inner, y, cz + Math.sin(a1) * inner, u1, 0.0f, shade, 0.92f, light);
			}
		}
	}

	@Override
	public ResourceLocation getTextureLocation(TornadoEntity entity) {
		return TEXTURE;
	}
}
