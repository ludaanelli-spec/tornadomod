package com.tornadomod.entity;

import com.tornadomod.TornadoMod;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import org.joml.Vector3f;

import java.util.List;

/**
 * A wandering tornado. Strength is an Enhanced Fujita rating from 0 (EF0) to 5 (EF5).
 * <p>
 * Server side: moves across the terrain, drags entities into a spiral, lifts them, hurts them at the core
 * (EF2+) and tears blocks out of the world, flinging them as falling-block debris.
 * Client side: draws the funnel with particles (there is no model).
 */
public class TornadoEntity extends Entity {
	private static final EntityDataAccessor<Integer> RATING = SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.INT);

	/** Hardest block (by destroy speed / hardness) each rating can tear loose: EF0 .. EF5. */
	private static final float[] MAX_HARDNESS = {0.4f, 1.0f, 2.5f, 4.0f, 8.0f, 60.0f};

	private int lifeTicks;
	private int debrisNearby;
	private int maxLife;
	private float heading;

	public TornadoEntity(EntityType<? extends TornadoEntity> type, Level level) {
		super(type, level);
		this.noPhysics = true;
		this.setNoGravity(true);
	}

	// ------------------------------------------------------------------ creation helpers

	/** Spawns a tornado on the ground at the given x/z (y is snapped to the terrain when the chunk is loaded). */
	public static TornadoEntity spawn(ServerLevel level, Vec3 pos, int rating, float heading) {
		TornadoEntity t = new TornadoEntity(TornadoMod.TORNADO.get(), level);
		double y = pos.y;
		if (isLoaded(level, pos.x, pos.z)) {
			y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(pos.x), Mth.floor(pos.z));
		}
		t.moveTo(pos.x, y, pos.z, 0.0f, 0.0f);
		t.setRating(rating < 0 ? randomRating(level.getRandom()) : rating);
		t.heading = heading;
		level.addFreshEntity(t);
		return t;
	}

	public static int randomRating(RandomSource random) {
		int roll = random.nextInt(100);
		if (roll < 35) return 0;
		if (roll < 65) return 1;
		if (roll < 85) return 2;
		if (roll < 95) return 3;
		if (roll < 99) return 4;
		return 5;
	}

	public static boolean isLoaded(ServerLevel level, double x, double z) {
		return level.hasChunk(Mth.floor(x) >> 4, Mth.floor(z) >> 4);
	}

	// ------------------------------------------------------------------ data

	@Override
	protected void defineSynchedData() {
		this.entityData.define(RATING, 1);
	}

	public int getRating() {
		return this.entityData.get(RATING);
	}

	public void setRating(int rating) {
		this.entityData.set(RATING, Mth.clamp(rating, 0, 5));
	}

	@Override
	protected void readAdditionalSaveData(CompoundTag tag) {
		setRating(tag.getInt("Rating"));
		lifeTicks = tag.getInt("Life");
		maxLife = tag.getInt("MaxLife");
		heading = tag.getFloat("Heading");
	}

	@Override
	protected void addAdditionalSaveData(CompoundTag tag) {
		tag.putInt("Rating", getRating());
		tag.putInt("Life", lifeTicks);
		tag.putInt("MaxLife", maxLife);
		tag.putFloat("Heading", heading);
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}

	@Override
	public boolean isAttackable() {
		return false;
	}

	/** The funnel is far bigger than the entity's tiny hitbox, so tell the renderer how much space it needs. */
	@Override
	public AABB getBoundingBoxForCulling() {
		double r = baseRadius() * 7.5; // the storm cloud and its inflow bands reach far out
		return new AABB(getX() - r, getY(), getZ() - r, getX() + r, getY() + funnelHeight() + 14, getZ() + r);
	}

	/** Visible from far away (320 blocks). */
	@Override
	public boolean shouldRenderAtSqrDistance(double distance) {
		return distance < 320.0 * 320.0;
	}

	// ------------------------------------------------------------------ geometry

	public double baseRadius() {
		int r = getRating();
		return 2.0 + 0.9 * r + 0.45 * r * r; // EF0 2, EF1 3.4, EF2 5.6, EF3 8.8, EF4 12.8, EF5 17.8 blocks
	}

	public double funnelHeight() {
		return 28 + 14 * getRating(); // EF0 28 blocks tall ... EF5 98 blocks tall
	}

	/** Funnel radius at a height above the ground: narrow at the base, wide at the top. */
	private double radiusAt(double h) {
		return baseRadius() * (0.8 + 1.2 * Math.min(1.0, h / funnelHeight()));
	}

	// ------------------------------------------------------------------ tick

	@Override
	public void tick() {
		super.tick();
		lifeTicks++;
		if (level().isClientSide) {
			clientTick();
		} else {
			serverTick((ServerLevel) level());
		}
	}

	private void serverTick(ServerLevel level) {
		if (maxLife == 0) {
			maxLife = 2400 + 600 * getRating() + random.nextInt(1200);
		}
		if (lifeTicks >= maxLife) {
			level.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 3, getZ(), 80, 3.0, 4.0, 3.0, 0.05);
			discard();
			return;
		}

		if (lifeTicks % 10 == 0) {
			countDebris(level);
		}
		wander(level);
		pullEntities(level);
		stormEffects(level);
		if (level.getGameRules().getBoolean(TornadoMod.RULE_DESTRUCTION)) {
			tearBlocks(level);
		}

		if (lifeTicks % 20 == 0) {
			level.playSound(null, getX(), getY() + 5, getZ(), SoundEvents.ENDER_DRAGON_FLAP,
					SoundSource.WEATHER, 5.0f, 0.5f);
		}
		if (lifeTicks % 100 == 1) {
			warnPlayers(level);
		}
	}

	private void wander(ServerLevel level) {
		heading += (random.nextFloat() - 0.5f) * 0.08f;
		double speed = 0.05 + 0.01 * getRating(); // blocks per tick (half of the first version)
		double nx = getX() + Math.cos(heading) * speed;
		double nz = getZ() + Math.sin(heading) * speed;
		if (!isLoaded(level, nx, nz)) {
			// reached the edge of the loaded world: turn around
			heading += (float) Math.PI * (0.5f + random.nextFloat() * 0.5f);
			return;
		}
		double ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(nx), Mth.floor(nz));
		double ny = getY() + (ground - getY()) * 0.15;
		setPos(nx, ny, nz);
	}

	private void pullEntities(ServerLevel level) {
		int r = getRating();
		double reach = baseRadius() * 5.3; // just enough to cover the wind zone at 70% of the funnel height
		double funnel = funnelHeight();
		double liftCap = 4 + 3 * r;
		double wind = 0.10 + 0.06 * r;

		AABB box = new AABB(getX() - reach, getY() - 2, getZ() - reach, getX() + reach, getY() + funnel * 0.7, getZ() + reach);
		List<Entity> targets = level.getEntities(this, box,
				e -> !(e instanceof TornadoEntity) && !e.isSpectator() && !(e instanceof Player p && p.isCreative()));

		for (Entity e : targets) {
			double dx = getX() - e.getX();
			double dz = getZ() - e.getZ();
			double dist = Math.sqrt(dx * dx + dz * dz);
			double h = Math.max(0, e.getY() - getY());
			double inner = radiusAt(h) * 1.8;  // inside the funnel: pulled in and lifted
			double outer = radiusAt(h) * 3.2;  // around it: strong wind that drags you towards it
			if (dist > outer) continue;
			boolean inInner = dist <= inner;

			// unit vector towards the centre, and the tangent around it
			double ux = dx / Math.max(dist, 0.5);
			double uz = dz / Math.max(dist, 0.5);
			double f = inInner
					? Mth.clamp(1.0 - dist / inner, 0.25, 1.0)
					: 0.12 * (1.0 - (dist - inner) / (outer - inner));
			double tx = (0.35 * ux - uz) * wind * f;
			double tz = (0.35 * uz + ux) * wind * f;
			boolean canLift = inInner && h < liftCap;

			if (e instanceof ServerPlayer) {
				// the server does not track a player's real velocity, so set it outright every tick
				e.setDeltaMovement(tx, canLift ? 0.10 + 0.05 * r : 0.0, tz);
			} else {
				Vec3 v = e.getDeltaMovement();
				double vy = v.y;
				if (canLift) {
					double ty = 0.25 + 0.06 * r;
					if (vy < ty) vy += (ty - vy) * 0.5;
				}
				e.setDeltaMovement(v.x + (tx - v.x) * 0.2, vy, v.z + (tz - v.z) * 0.2);
			}
			e.hurtMarked = true;

			if (r >= 2 && lifeTicks % 10 == 0 && dist < baseRadius() * 0.6 && h < funnel * 0.4
					&& e instanceof LivingEntity living) {
				living.hurt(level.damageSources().generic(), (float) (2 * (r - 1))); // EF2: 2 ... EF5: 8 every half second
			}
		}
	}

	/** A tornado brings its storm with it: it makes it rain, thunder and strike lightning around itself. */
	private void stormEffects(ServerLevel level) {
		int r = getRating();
		if (level.dimension() == Level.OVERWORLD && lifeTicks % 100 == 1 && !level.isThundering()) {
			level.setWeatherParameters(0, 12000, true, true);
		}
		if (lifeTicks % 20 == 0 && random.nextFloat() < 0.18f + 0.04f * r) {
			double a = random.nextDouble() * Math.PI * 2;
			double d = baseRadius() * 1.5 + random.nextDouble() * (20 + baseRadius() * 2);
			double x = getX() + Math.cos(a) * d;
			double z = getZ() + Math.sin(a) * d;
			if (!isLoaded(level, x, z)) return;
			int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, Mth.floor(x), Mth.floor(z));
			LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
			if (bolt != null) {
				bolt.moveTo(x, y, z);
				bolt.setVisualOnly(r < 2); // EF0-1: just the flash. EF2+: real lightning that can start fires
				level.addFreshEntity(bolt);
			}
		}
	}

	private void tearBlocks(ServerLevel level) {
		if (lifeTicks % 2 != 0) return;
		int r = getRating();
		if (debrisNearby >= debrisCap()) return; // enough debris in the air already: keeps the game smooth
		float maxHardness = MAX_HARDNESS[r];
		double reach = 10 + 8 * r;          // how high above the ground it tears things off (EF5: 50 blocks)
		int attempts = 14 + 14 * r;
		int budget = 2 + 3 * r; // max blocks converted per pass

		// everything standing above the ground: trees, houses, fences, crops...
		for (int i = 0; i < attempts && budget > 0; i++) {
			double h = random.nextDouble() * reach;
			double rad = radiusAt(h) * Math.sqrt(random.nextDouble());
			double a = random.nextDouble() * Math.PI * 2;
			double bx = getX() + Math.cos(a) * rad;
			double bz = getZ() + Math.sin(a) * rad;
			if (!isLoaded(level, bx, bz)) continue;

			BlockPos pos = BlockPos.containing(bx, getY() + h, bz);
			BlockState state = level.getBlockState(pos);
			if (state.isAir() || !state.getFluidState().isEmpty() || state.hasBlockEntity()) continue;

			float hardness = state.getDestroySpeed(level, pos);
			if (hardness < 0 || hardness > maxHardness) continue;
			if (!isExposed(level, pos)) continue;

			launch(level, pos, state, r);
			budget--;
		}

		if (lifeTicks % 4 == 0) {
			scourGround(level);
		}
	}

	/**
	 * Digs into the ground under the funnel, so a tornado leaves a torn-up scar behind it.
	 * EF1 strips grass and topsoil, stronger ones dig deeper and take stone too.
	 */
	private void scourGround(ServerLevel level) {
		int r = getRating();
		if (r < 1) return;
		float maxHardness = MAX_HARDNESS[r];
		double radius = baseRadius() * 1.5;
		int tries = 8 + 12 * r;
		int budget = 2 + 3 * r;
		int depth = 1 + r; // EF1: 2 blocks deep ... EF5: 6 blocks deep

		for (int i = 0; i < tries && budget > 0; i++) {
			double a = random.nextDouble() * Math.PI * 2;
			double rr = radius * Math.sqrt(random.nextDouble());
			double x = getX() + Math.cos(a) * rr;
			double z = getZ() + Math.sin(a) * rr;
			if (!isLoaded(level, x, z)) continue;

			int bx = Mth.floor(x);
			int bz = Mth.floor(z);
			int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz); // first air above the ground

			for (int d = 1; d <= depth && budget > 0; d++) {
				BlockPos pos = new BlockPos(bx, top - d, bz);
				BlockState state = level.getBlockState(pos);
				if (state.isAir() || !state.getFluidState().isEmpty() || state.hasBlockEntity()) break;
				float hardness = state.getDestroySpeed(level, pos);
				if (hardness < 0 || hardness > maxHardness) break;
				launch(level, pos, state, r);
				budget--;
			}
		}
	}

	private static boolean isTerrain(BlockState state) {
		return state.is(BlockTags.DIRT) || state.is(BlockTags.SAND) || state.is(BlockTags.BASE_STONE_OVERWORLD);
	}

	private static boolean isExposed(ServerLevel level, BlockPos pos) {
		for (Direction d : Direction.values()) {
			if (level.getBlockState(pos.relative(d)).isAir()) return true;
		}
		return false;
	}

	private int debrisCap() {
		return 90 + 30 * getRating(); // EF0: 90 flying blocks ... EF5: 240
	}

	/** Counts the flying blocks around the tornado and removes the ones that have been in the air too long. */
	private void countDebris(ServerLevel level) {
		double rr = baseRadius() * 8.0;
		AABB box = new AABB(getX() - rr, getY() - 8, getZ() - rr, getX() + rr, getY() + funnelHeight(), getZ() + rr);
		int n = 0;
		for (FallingBlockEntity e : level.getEntitiesOfClass(FallingBlockEntity.class, box)) {
			if (e.tickCount > 100) {
				e.discard();
			} else {
				n++;
			}
		}
		debrisNearby = n;
	}

	private void launch(ServerLevel level, BlockPos pos, BlockState state, int r) {
		if (debrisNearby >= debrisCap()) return;
		debrisNearby++;
		FallingBlockEntity debris = FallingBlockEntity.fall(level, pos, state); // this removes the block from the world
		double ox = pos.getX() + 0.5 - getX();
		double oz = pos.getZ() + 0.5 - getZ();
		double d = Math.max(0.5, Math.sqrt(ox * ox + oz * oz));
		ox /= d;
		oz /= d;
		double spin = 0.30 + 0.07 * r;
		debris.setDeltaMovement(
				oz * spin + ox * 0.08,
				0.30 + random.nextDouble() * (0.15 + 0.08 * r),
				-ox * spin + oz * 0.08);
		debris.hurtMarked = true;
		// Most debris vanishes when it lands, so the damage is real. Ground chunks vanish even more often.
		if (random.nextFloat() < (isTerrain(state) ? 0.92f : 0.75f)) {
			debris.disableDrop();
		}
	}

	private void warnPlayers(ServerLevel level) {
		Component msg = Component.literal("Tornado warning: EF" + getRating() + " tornado nearby!").withStyle(ChatFormatting.RED);
		for (ServerPlayer p : level.players()) {
			if (p.distanceToSqr(this) < 100.0 * 100.0) {
				p.displayClientMessage(msg, true);
			}
		}
	}

	// ------------------------------------------------------------------ client visuals

	/** Radius used for drawing: a real funnel is much narrower at the ground than at the cloud. */
	private double visualRadius(double h) {
		double t = Math.min(1.0, h / funnelHeight());
		return radiusAt(h) * (0.45 + 0.55 * t);
	}

	private static DustParticleOptions dust(float r, float g, float b, float scale) {
		return new DustParticleOptions(new Vector3f(r, g, b), scale);
	}

	private void clientTick() {
		Level lvl = level();
		if (lvl.getNearestPlayer(this, 100.0) == null) return; // nobody close enough to see the dust: skip the particles
		int r = getRating();
		double funnel = funnelHeight();
		double gx = getX();
		double gy = getY();
		double gz = getZ();

		// The funnel and storm cloud are drawn as a 3D model by TornadoRenderer.
		// Here: dust cloud at the base, and chunks of the ground flying around the funnel.
		BlockState below = lvl.getBlockState(BlockPos.containing(gx, gy - 1, gz));
		boolean overWater = !below.getFluidState().isEmpty();
		if (below.isAir() || overWater) {
			below = Blocks.DIRT.defaultBlockState();
		}
		BlockParticleOption debris = new BlockParticleOption(ParticleTypes.BLOCK, below);

		for (int i = 0; i < 3 + r; i++) {
			double a = random.nextDouble() * Math.PI * 2;
			double rr = baseRadius() * (0.4 + 1.4 * random.nextDouble());
			DustParticleOptions base = overWater ? dust(0.80f, 0.85f, 0.90f, 2.6f) : dust(0.40f, 0.33f, 0.26f, 2.6f);
			lvl.addParticle(base, true,
					gx + Math.cos(a) * rr, gy + 0.2 + random.nextDouble() * 2, gz + Math.sin(a) * rr,
					Math.sin(a) * 0.15, 0.08, -Math.cos(a) * 0.15);
		}
		if (!overWater) {
			for (int i = 0; i < 2 + r; i++) {
				double h = random.nextDouble() * funnel * 0.5;
				double a = random.nextDouble() * Math.PI * 2;
				double rr = visualRadius(h) * (0.6 + 0.6 * random.nextDouble());
				lvl.addParticle(debris, true,
						gx + Math.cos(a) * rr, gy + h, gz + Math.sin(a) * rr,
						Math.sin(a) * 0.35, 0.12, -Math.cos(a) * 0.35);
			}
		}
	}
}
