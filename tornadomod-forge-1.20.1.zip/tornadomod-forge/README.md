# Tornado Mod (Forge, Minecraft 1.20.1)

Adds tornadoes rated **EF0 to EF5** that wander across the land, drag entities into a spiral, lift them,
tear blocks out of the world and fling them as debris. (Forge port of the Fabric 1.21.1 version.)

## Features

- **Tornado entity** with six strengths. Stronger = much wider (EF0 4 blocks across, EF5 about 36), taller (28 up to 98 blocks), longer-lived,
  digging deeper (up to 6 blocks) and able to tear harder blocks:
  EF0 rips leaves/glass/plants, EF1+ strips grass and topsoil and digs a scar into the ground (deeper with strength), EF2 takes wood and stone bricks, EF5 can remove obsidian.
- **Looks like real clouds:** a soft cloud funnel, a dark storm cloud on top, and cloud bands that stream in and gather into it.
- **Brings its own storm:** it makes it rain and thunder and strikes lightning around itself (EF2+ lightning is real and can start fires).
- **Wind and lift:** entities near the funnel are spun inward and carried upward. EF2+ also hurt anything near the core.
  Creative and spectator players are ignored.
- **Tornado Wand:** right-click to summon one where you look, sneak + right-click to change the strength.
  Craft it with: feather (top), lightning rod (middle), stick (bottom).
- **Natural spawns:** during Overworld thunderstorms a tornado forms about every 25 s on average (rain alone: about every 4 minutes), 50-90 blocks from a random player. Try `/tornado storm` and wait a minute.
  Players within 100 blocks get a red action-bar warning.
- **Commands** (op level 2):
  - `/tornado spawn [rating 0-5] [x y z]` (random rating if omitted)
  - `/tornado clear` removes every tornado
  - `/tornado storm` starts a thunderstorm
- **Game rules:** `tornadoSpawns` (natural formation) and `tornadoDestruction` (block damage), both default `true`.

## Easiest: free cloud build

No installs needed. See `GET-THE-JAR-FREE.md`: upload the project to a free GitHub account and it builds the jar for you.

## Building on your own computer

You need **JDK 17**.

1. This project has no `gradle-wrapper.jar` (it can't be generated offline). Either:
   - open the folder in IntelliJ IDEA or Eclipse (they import Gradle projects automatically), or
   - install Gradle 8.8 and run `gradle wrapper --gradle-version 8.8` once in this folder.
2. Run `./gradlew build` (Windows: `gradlew.bat build`). The jar appears in `build/libs/tornadomod-1.0.0.jar`.
3. Test in a dev client with `./gradlew runClient`.
4. To play: drop the jar into the `mods` folder of a **Forge 47.x** install of Minecraft 1.20.1. No other mods needed.

Quick test in a creative world: `/tornado spawn 3`, then watch from a distance.

## Tuning

Everything is in `TornadoEntity.java`: `MAX_HARDNESS` (what each rating can destroy), `baseRadius()`,
`funnelHeight()`, the wind speeds in `pullEntities()`, and the lifetime in `serverTick()`.
Spawn frequency and distance are in `TornadoSpawner.java`.

## Notes

- The funnel is drawn with particles, not a 3D model.
- The wand texture is a generated placeholder. Replace `assets/tornadomod/textures/item/tornado_wand.png` (16x16) with your own.
- Uses official Mojang mappings. If a Forge version bump breaks compilation, paste the error and it can be fixed quickly.

## Performance

- Flying debris is capped per tornado (90 at EF0 up to 240 at EF5) and removed after 5 seconds in the air.
- Dust particles are skipped when no player is within 100 blocks.
- Far away, the clouds are drawn with fewer, bigger puffs (level of detail).
- If it's still too heavy, use `/gamerule tornadoDestruction false`, which removes all the block-flinging.
